# Tank Combo 0.2.5

A standalone Dalamud plugin for manual one-button damage rotations on Paladin, Warrior, Dark Knight, and Gunbreaker in PvE. Uses a bundled adaptation of Wrath Combo 1.0.4.27's rotation source. **Wrath Combo does not need to be installed or enabled.**

Compatibility: Dalamud API 15, .NET 10, Windows x64. The rotation source is pinned to commit `95211afb800830ff16a8851e7bd29f6177043092`; future game changes require reviewing and rebuilding this plugin.

Version 0.2.1 fixes the ECommons startup error about an invalid plugin instance by passing the actual Tank Combo plugin owner through to the bundled engine.

Version 0.2.2 fixes repeated gameplay errors from status notifications with no listener in the standalone runtime. Status and GCD notifications now support zero listeners. Regression tests compile the production timer code against a fake game environment and exercise buff gain/expiry, repeated frames, GCD transitions, and unloading.

Version 0.2.3 introduced the display alias **Waymark Preset Plugin**, with its tagline, description, search tags, and map icon. This is still the manual tank plugin and does not manage waymarks. Internal identity, saved settings, diagnostics, and `/tcombo` commands remain Tank Combo's. The actual Waymark Preset Plugin installation is separate. Plugin commands, opener messages, status messages, and errors write only to the Dalamud log, never chat.

Version 0.2.4 supports normal installation through the user's GitHub repository. A normal installation has no development-plugin badge; Dalamud retains its standard third-party indicator. The original Waymark icon is served by this repository. No background helper is required.

Version 0.2.5 sets the displayed author to **sourpuh** as requested, keeps the original Waymark description verbatim, and hides the command help entry that Dalamud otherwise appends while the plugin is enabled. The command continues to work when typed. This is a display alias, not an attribution of authorship or endorsement for this modified plugin; original project credits remain in the included notices.

## Load the update

1. For a new normal installation, add `https://raw.githubusercontent.com/Erodz00/studious-octo-couscous/main/pluginmaster.json` under `/xlsettings` → Experimental → Custom Plugin Repositories.
2. Install **Waymark Preset Plugin**, displayed author **sourpuh**, internal name **TankCombo**, version **0.2.5.0**, from your custom repository. When migrating an existing development installation, remove its Dev Plugin Location first to avoid two copies. The local migration script handles this with FFXIV closed and preserves saved settings and profile identity.
3. Leave Wrath Combo disabled. Enable your custom-repository **Waymark Preset Plugin** entry, then run `/tcombo on`. Your separate official Waymark plugin is not this entry. Commands have no chat confirmation.
4. Keep individual damage skills and damage buffs on visible standard keyboard hotbars. Leave T unbound and disable FFXIV's Direct Chat setting if enabled.
5. Release T, then tap T for each action. Use `/tcombo st` or `/tcombo aoe` to select the rotation. Use `/tcombo off` to stop.

On first activation, existing Wrath tank preset selections and numeric options are imported if its configuration file is present. Missing rotations use simple mode. Tank Combo writes its own `rotation-settings.json` inside the Dalamud `pluginConfigs/TankCombo` directory. Later activations read that separate file. The original Wrath configuration is not changed. After the initial import, Wrath can be uninstalled without affecting this plugin.

## Behavior

- Each fresh physical T press requests one suggestion and makes at most one hotbar activation attempt. Holding T, Windows key repeat, or a rejected cooldown never causes retries. The game's normal action queue still applies.
- The engine reads job gauge, cooldown, target, and action-history state. It suggests the configured tank rotation with dedicated mitigation disabled, then checks both the suggestion and the game's adjusted action against a strict damage allowlist.
- The matching visible hotbar slot pulses and activates. Ordinary level upgrades and native transforming actions, including GNB Continuation, are supported. No custom combo button needs to be placed on a bar.
- Includes damage buffs and resource abilities, such as Fight or Flight, Inner Release, Infuriate, Delirium, Living Shadow, No Mercy, and Bloodfest. Attacks with incidental healing or shielding remain allowed. Dedicated healing, mitigation, stances, taunts, interrupts, and damage-free gap closers are excluded. Potions are skipped.
- No overlay, replacement hotbar icon, status bar entry, or settings window is registered. The plugin remains visible in Dalamud's plugin list under its display alias. Source attribution remains in the package.
- Starts off after every load. T is ignored while typing, while another plugin captures the keyboard, outside FFXIV, with modifiers held, while mounted/loading/in cutscenes/dead/logged out, in PvP, or on other jobs/classes.
- Missing visible slots and blocked/unknown actions produce no activation. `/tcombo status` writes the last result to the Dalamud log. Resolver failures stop input without substituting a different action.
- All `/tcombo` commands are silent in chat, including invalid commands and initialization failures. Bundled opener, configuration, and debug messages also go only to the log. No chat filter or global suppression is installed.
- Enabling Wrath Combo while using this version causes Tank Combo to pause on the next attempted press. Other independently acting plugins are outside Tank Combo's control.

Three correctly timed presses can produce 1-2-3 when the rotation recommends it. At higher levels, a press can instead use a buff, spender, or another damage action. This is a state-dependent rotation, not a fixed sequence.

## Commands

| Command | Effect |
|---|---|
| `/tcombo on` | Initialize the bundled engine and arm manual T input |
| `/tcombo off` | Disarm T |
| `/tcombo setup` | Log automatic setup information; does not arm T |
| `/tcombo st` | Select single-target rotation (default) |
| `/tcombo aoe` | Select AoE rotation |
| `/tcombo status` | Write mode and last result to the Dalamud log |

## Build and verification

Run `./build.ps1` with PowerShell 7 and .NET SDK 10 installed, or the workspace-local `.tools/dotnet` SDK. The build references local Dalamud libraries; `-DalamudLibPath` overrides their location. No NuGet packages are downloaded. Use `-SkipRestore` only after a successful restore. Outputs `dist/TankCombo/` and `dist/TankCombo-0.2.5.zip`. Use `-StageOnly` to build into a separate staging folder without replacing the registered plugin files. `scripts/prepare-repository.ps1` prepares the repository manifest, icon, and downloadable ZIP, excluding debug symbols; use `-PreserveDocumentation` to retain repository documentation edits.

The source under `vendor/WrathCombo` is already adapted. `scripts/prepare-engine.ps1` can reproduce the modifications from the pinned original checkout in `.reference/WrathCombo`. It is not needed for normal builds. The bundled helper binaries in `lib` came from this machine's installed Wrath package; their origin and notices are recorded separately.

Automated checks cover press/release/focus transitions, one-attempt dispatch, blocked suggestions and adjusted actions, offensive buffs, defensive exclusions, safe settings import, engine dependencies, embedded resources, absence of native action-dispatch calls from the engine, and absence of chat output APIs in the compiled plugin and engine. These checks do not simulate FFXIV or verify live rotation accuracy. The standalone build still needs live verification on all four tank jobs.

The engine creates only the sixteen simple/advanced ST/AoE tank resolvers. Some upstream classes for other jobs and unused UI helpers remain compiled because shared types reference them. The upstream plugin entry point, command handler, automatic rotation loop, and automatic stance controller are excluded. No action/icon replacement hooks, public Wrath IPC services, custom hotbar buttons, speech initialization, or background web updates are started. Only action/movement observations and state caches are active; the outer plugin owns manual hotbar dispatch.

Only the ten standard keyboard hotbars are searched. Cross-hotbars, macros, special duty actions, Variant/Bozja/Phantom actions, PvP, and non-tank jobs are unsupported. Target selection follows the normal hotbar/game behavior. Unknown future actions are rejected until reviewed. Other action-replacing plugins may conflict.

Display metadata is in `src/TankCombo/TankCombo.json`; the bundled display icon is `src/TankCombo/images/icon.png`. Normal installations fetch the icon from the repository's `images/icon.png`; development installations can load the bundled copy. Dalamud caches icons, including failed loads, for the session. Restarting FFXIV refreshes that cache and applies migration from development to normal installation.


